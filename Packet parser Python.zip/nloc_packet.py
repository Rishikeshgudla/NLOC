"""
nloc_packet.py - builds / parses N-LOC packets (must match rtl/pkt_rx.vhd).

  0xA5 | CMD | YAW_lo YAW_hi | NLM | NLM x (EGO_lo EGO_hi | 144 pixel bytes) | CSUM
  CMD: 1 = LEARN, 2 = QUERY.  Angles are integer degrees 0..359.
  CSUM = XOR of every byte from CMD to the last pixel.
"""
import numpy as np
from functools import reduce

SYNC, CMD_LEARN, CMD_QUERY = 0xA5, 1, 2
PATCH, NL_MAX = 144, 16


def build_packet(cmd, yaw_deg, landmarks):
    """landmarks: list of (patch, ego_deg); patch = 144 gray values 0..255."""
    assert cmd in (CMD_LEARN, CMD_QUERY)
    assert 1 <= len(landmarks) <= NL_MAX
    yaw = int(round(yaw_deg)) % 360
    body = bytearray([cmd, yaw & 255, yaw >> 8, len(landmarks)])
    for patch, ego_deg in landmarks:
        assert len(patch) == PATCH
        ego = int(round(ego_deg)) % 360
        body += bytes([ego & 255, ego >> 8])
        body += bytes(np.clip(np.asarray(patch), 0, 255).astype(np.uint8))
    csum = reduce(lambda a, b: a ^ b, body, 0)
    return bytes([SYNC]) + bytes(body) + bytes([csum])


def parse_packet(pkt):
    """Inverse of build_packet (used to self-check). Returns (cmd, yaw, landmarks)."""
    assert pkt[0] == SYNC
    body, csum = pkt[1:-1], pkt[-1]
    assert reduce(lambda a, b: a ^ b, body, 0) == csum, "bad checksum"
    cmd, yaw, nlm = body[0], body[1] | (body[2] << 8), body[3]
    lms, i = [], 4
    for _ in range(nlm):
        ego = body[i] | (body[i + 1] << 8)
        lms.append((np.frombuffer(body[i + 2:i + 2 + PATCH], np.uint8), ego))
        i += 2 + PATCH
    assert i == len(body)
    return cmd, yaw, lms


if __name__ == "__main__":
    import nloc_golden as g
    rng = np.random.default_rng(1)
    protos, places = g.make_world(rng)
    lm = g.view(protos, places[0], 100.0, rng, pix_noise=5)
    pkt = build_packet(CMD_QUERY, 100.0, lm)
    cmd, yaw, back = parse_packet(pkt)
    assert cmd == CMD_QUERY and yaw == 100 and len(back) == len(lm)
    assert all((b[0] == np.clip(a[0], 0, 255)).all() for a, b in zip(lm, back))
    print(f"packet: {len(pkt)} bytes, checksum 0x{pkt[-1]:02X}, round trip OK")
    for baud in (115200, 921600):
        print(f"  at {baud} baud: {len(pkt) * 10 / baud * 1000:.0f} ms per image")
